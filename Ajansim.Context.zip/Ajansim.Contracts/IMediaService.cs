﻿using Ajansim.Core.Abstarcts;
using Ajansim.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ajansim.Contracts
{
    public interface IMediaService : IBaseRepository<Media>
    {
    }
}
